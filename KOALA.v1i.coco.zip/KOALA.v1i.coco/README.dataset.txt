# KOALA > 2024-11-25 6:43pm
https://universe.roboflow.com/segmentation-hfbgr/koala-3nldz

Provided by a Roboflow user
License: CC BY 4.0

